import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';

const lifestyleItems = [
  {
    image: 'https://images.pexels.com/photos/16009530/pexels-photo-16009530.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400',
    title: 'Sunsets\nthat stop time.',
    sub: 'Pacific Ocean · Every Evening',
    size: 'large',
  },
  {
    image: 'https://images.pexels.com/photos/38145936/pexels-photo-38145936.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700',
    title: 'Where rainforest\nmeets luxury.',
    sub: 'Nature · Privacy · Tranquility',
    size: 'small',
  },
  {
    image: 'https://images.pexels.com/photos/34790496/pexels-photo-34790496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700',
    title: 'Your infinity pool\nwith no horizon.',
    sub: 'Luxury Living · Year Round',
    size: 'small',
  },
  {
    image: 'https://images.pexels.com/photos/4628191/pexels-photo-4628191.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400',
    title: 'Freedom.\nPrivacy. Home.',
    sub: 'Investment · Lifestyle · Legacy',
    size: 'large',
  },
];

export default function LifestyleSection() {
  const { ref, inView } = useInView({ threshold: 0.05, triggerOnce: true });

  return (
    <section id="lifestyle" ref={ref} className="bg-white py-24 lg:py-40 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-20 lg:mb-32"
        >
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
            <span className="section-label">The Costa Rica Life</span>
            <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
          </div>
          <h2
            className="text-black font-light leading-[1.05] mx-auto"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              maxWidth: '600px',
            }}
          >
            It's Not Just a Property.
            <br />
            <em>It's a Whole New Life.</em>
          </h2>
          <p className="text-black/40 text-sm font-light mt-6 max-w-md mx-auto leading-relaxed">
            Ocean. Rainforest. Wellness. Freedom. Investment. 
            Costa Rica offers everything a curated life demands.
          </p>
        </motion.div>

        {/* Lifestyle grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

          {/* First large image */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative overflow-hidden group cursor-pointer lg:row-span-1"
            style={{ height: 'clamp(300px, 50vw, 600px)' }}
          >
            <img
              src={lifestyleItems[0].image}
              alt={lifestyleItems[0].title}
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)',
              }}
            />
            <div className="absolute bottom-8 left-8">
              <p
                className="text-white font-light text-2xl lg:text-3xl mb-2 leading-tight"
                style={{ fontFamily: 'Playfair Display, serif', whiteSpace: 'pre-line' }}
              >
                {lifestyleItems[0].title}
              </p>
              <p className="text-white/40 text-[10px] tracking-[0.3em] uppercase">
                {lifestyleItems[0].sub}
              </p>
            </div>
          </motion.div>

          {/* Right column - two smaller */}
          <div className="grid grid-rows-2 gap-4">
            {[lifestyleItems[1], lifestyleItems[2]].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 1, delay: 0.3 + i * 0.15 }}
                className="relative overflow-hidden group cursor-pointer"
                style={{ height: 'clamp(150px, 25vw, 295px)' }}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background: 'linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.1) 60%, transparent 100%)',
                  }}
                />
                <div className="absolute bottom-6 left-6">
                  <p
                    className="text-white font-light text-lg lg:text-xl mb-1 leading-tight"
                    style={{ fontFamily: 'Playfair Display, serif', whiteSpace: 'pre-line' }}
                  >
                    {item.title}
                  </p>
                  <p className="text-white/40 text-[9px] tracking-[0.25em] uppercase">
                    {item.sub}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Second row - single full width */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.6 }}
          className="relative overflow-hidden group cursor-pointer mt-4"
          style={{ height: 'clamp(250px, 40vw, 500px)' }}
        >
          <img
            src={lifestyleItems[3].image}
            alt={lifestyleItems[3].title}
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          />
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)',
            }}
          />
          <div className="absolute bottom-10 left-10 right-10 flex items-end justify-between">
            <div>
              <p
                className="text-white font-light leading-tight mb-2"
                style={{
                  fontFamily: 'Playfair Display, serif',
                  fontSize: 'clamp(1.5rem, 3vw, 3rem)',
                  whiteSpace: 'pre-line',
                }}
              >
                {lifestyleItems[3].title}
              </p>
              <p className="text-white/40 text-[10px] tracking-[0.3em] uppercase">
                {lifestyleItems[3].sub}
              </p>
            </div>
            <button
              onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="hidden lg:flex luxury-btn border-white/30 text-white text-[10px]"
            >
              Begin Your Journey
            </button>
          </div>
        </motion.div>

        {/* Lifestyle tags */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap gap-6 mt-16 justify-center"
        >
          {['Ocean Living', 'Rainforest', 'Wellness', 'Privacy', 'Investment', 'Surfing', 'Adventure', 'Gourmet', 'Community'].map((tag) => (
            <span
              key={tag}
              className="text-black/30 text-[10px] tracking-[0.35em] uppercase font-light hover:text-black/60 transition-colors cursor-pointer"
            >
              {tag}
            </span>
          ))}
        </motion.div>

      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function LoadingScreen() {
  const [visible, setVisible] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 2800);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 4;
      });
    }, 80);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center"
        >
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-center mb-16"
          >
            <div
              className="text-white text-3xl font-light tracking-[0.2em] uppercase mb-2"
              style={{ fontFamily: 'Playfair Display, serif' }}
            >
              Tropical Realty
            </div>
            <div className="text-white/30 text-[10px] tracking-[0.5em] uppercase">
              Costa Rica
            </div>
          </motion.div>

          {/* Progress bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="w-48 h-px bg-white/10 relative overflow-hidden"
          >
            <motion.div
              className="absolute top-0 left-0 h-full"
              style={{ backgroundColor: '#D4AF37', width: `${progress}%`, transition: 'width 0.08s linear' }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-4 text-white/20 text-[9px] tracking-[0.5em] uppercase"
          >
            {progress < 100 ? 'Loading Experience' : 'Welcome'}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

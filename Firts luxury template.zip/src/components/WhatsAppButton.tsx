import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';

export default function WhatsAppButton() {
  return (
    <motion.a
      href="https://wa.me/50683888809?text=Hello,%20I'm%20interested%20in%20luxury%20properties%20in%20Costa%20Rica."
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 3, duration: 0.5 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 shadow-2xl group"
      style={{ backgroundColor: '#25D366' }}
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={20} className="text-white" />
      <span className="text-white text-xs tracking-wider font-light hidden sm:block">
        WhatsApp
      </span>
      {/* Pulse animation */}
      <div
        className="absolute inset-0 animate-ping opacity-20"
        style={{ backgroundColor: '#25D366' }}
      />
    </motion.a>
  );
}

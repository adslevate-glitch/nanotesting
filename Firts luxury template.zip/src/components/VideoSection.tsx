import { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, X } from 'lucide-react';

export default function VideoSection() {
  const { ref, inView } = useInView({ threshold: 0.2, triggerOnce: true });
  const [videoOpen, setVideoOpen] = useState(false);

  return (
    <>
      <section ref={ref} className="relative overflow-hidden" style={{ height: 'clamp(400px, 60vh, 700px)' }}>
        {/* Background */}
        <img
          src="https://images.pexels.com/photos/12720677/pexels-photo-12720677.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600"
          alt="Luxury Costa Rica"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{ background: 'rgba(0,0,0,0.55)' }}
        />

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Experience Costa Rica</span>
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
            </div>

            <h2
              className="text-white font-light mb-10"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(1.8rem, 4vw, 3rem)',
              }}
            >
              See the Life That Awaits You
            </h2>

            {/* Luxury play button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setVideoOpen(true)}
              className="relative group flex items-center justify-center mx-auto"
            >
              {/* Outer ring */}
              <div
                className="absolute w-24 h-24 rounded-full border opacity-30 animate-ping"
                style={{ borderColor: '#D4AF37', animationDuration: '2s' }}
              />
              <div
                className="absolute w-20 h-20 rounded-full border opacity-50"
                style={{ borderColor: '#D4AF37' }}
              />
              {/* Inner circle */}
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: '#D4AF37' }}
              >
                <Play size={18} fill="#000" className="ml-1" />
              </div>
            </motion.button>

            <p className="text-white/40 text-xs tracking-[0.3em] uppercase mt-8">
              Watch Our Story
            </p>
          </motion.div>
        </div>
      </section>

      {/* Video Modal */}
      <AnimatePresence>
        {videoOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4 lg:p-16"
            onClick={() => setVideoOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="relative w-full max-w-5xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setVideoOpen(false)}
                className="absolute -top-12 right-0 text-white/60 hover:text-white transition-colors flex items-center gap-2 text-xs tracking-widest uppercase"
              >
                <X size={14} />
                Close
              </button>
              <div className="aspect-video bg-black">
                <iframe
                  width="100%"
                  height="100%"
                  src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
                  title="Tropical Realty Costa Rica"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

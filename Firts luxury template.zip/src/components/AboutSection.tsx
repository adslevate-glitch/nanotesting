import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function AboutSection() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section id="about" ref={ref} className="bg-black py-24 lg:py-40 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-32 items-center">

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative"
          >
            <div className="relative overflow-hidden aspect-[3/4] lg:aspect-[4/5]">
              <img
                src="https://images.pexels.com/photos/35386131/pexels-photo-35386131.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800"
                alt="Jorge - Tropical Realty Costa Rica"
                className="w-full h-full object-cover"
              />
              {/* Gold frame accent */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  boxShadow: 'inset 0 0 0 1px rgba(212,175,55,0.2)',
                }}
              />
            </div>

            {/* Floating card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5, duration: 0.7 }}
              className="absolute -bottom-6 -right-6 lg:-bottom-8 lg:-right-8 bg-black border border-white/10 p-6 lg:p-8"
            >
              <div
                className="text-5xl text-white font-light mb-1"
                style={{ fontFamily: 'Cormorant Garamond, serif' }}
              >
                15+
              </div>
              <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase">
                Years of Trust
              </div>
            </motion.div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Our Story</span>
            </div>

            <h2
              className="text-white font-light leading-[1.05] mb-8"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(1.8rem, 3vw, 3rem)',
              }}
            >
              Built on Trust.
              <br />
              <em style={{ color: '#D4AF37' }}>Driven by Excellence.</em>
            </h2>

            <div className="space-y-5 text-white/50 text-sm font-light leading-[1.9]">
              <p>
                Since 2008, Tropical Realty Costa Rica has been the definitive bridge between international buyers and Costa Rica's finest properties. Founded by Jorge with a vision of honesty, expertise, and personalized service.
              </p>
              <p>
                We are not a traditional real estate agency. We are luxury property consultants — combining deep local knowledge with international standards to deliver an experience that matches the quality of the properties we represent.
              </p>
              <p>
                Every client is unique. Every transaction is personal. From your first consultation to handing you the keys — and beyond — we are your partner in Costa Rica.
              </p>
            </div>

            {/* Signature */}
            <div className="mt-10 pb-8 border-b border-white/10">
              <div className="flex items-center gap-6">
                <div>
                  <div
                    className="text-white text-2xl font-light italic mb-1"
                    style={{ fontFamily: 'Cormorant Garamond, serif' }}
                  >
                    Jorge Arroyo
                  </div>
                  <div className="text-white/30 text-[10px] tracking-[0.3em] uppercase">
                    Founder & CEO · Tropical Realty Costa Rica
                  </div>
                </div>
              </div>
            </div>

            {/* Contact info */}
            <div className="mt-8 grid grid-cols-2 gap-4">
              <a
                href="tel:+50683888809"
                className="flex flex-col gap-1 group"
              >
                <div className="text-white/20 text-[9px] tracking-[0.3em] uppercase">Phone</div>
                <div className="text-white text-sm font-light group-hover:text-white/60 transition-colors">
                  +506 8388 8809
                </div>
              </a>
              <a
                href="mailto:Jorge@tropicalrealtycostarica.com"
                className="flex flex-col gap-1 group"
              >
                <div className="text-white/20 text-[9px] tracking-[0.3em] uppercase">Email</div>
                <div className="text-white text-sm font-light group-hover:text-white/60 transition-colors truncate">
                  Jorge@tropicalrealtycostarica.com
                </div>
              </a>
            </div>

            {/* CTA */}
            <div className="mt-10">
              <button
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="luxury-btn group"
              >
                <span>Meet Our Team</span>
                <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-2" />
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

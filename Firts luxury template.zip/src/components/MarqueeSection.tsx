import { motion } from 'framer-motion';

const items = [
  'Luxury Homes', '·', 'Investment Properties', '·', 'Ocean View Estates', '·',
  'Private Villas', '·', 'Beachfront Land', '·', 'Rainforest Retreats', '·',
  'Wellness Properties', '·', 'Surf Estates', '·', 'Mountain Retreats', '·',
];

export default function MarqueeSection() {
  return (
    <div
      className="py-5 overflow-hidden border-y"
      style={{ borderColor: 'rgba(212,175,55,0.2)', backgroundColor: '#0A0A0A' }}
    >
      <motion.div
        className="flex gap-8 whitespace-nowrap"
        animate={{ x: ['0%', '-50%'] }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: 'linear',
          repeatType: 'loop',
        }}
      >
        {[...items, ...items].map((item, i) => (
          <span
            key={i}
            className={`text-[11px] tracking-[0.35em] uppercase font-light flex-shrink-0 ${
              item === '·' ? '' : 'text-white/40 hover:text-white/70 transition-colors cursor-default'
            }`}
            style={{ color: item === '·' ? '#D4AF37' : undefined }}
          >
            {item}
          </span>
        ))}
      </motion.div>
    </div>
  );
}

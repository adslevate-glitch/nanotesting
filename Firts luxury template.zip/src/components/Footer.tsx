import { useState } from 'react';
import { ArrowRight } from 'lucide-react';

const footerLinks = {
  Properties: ['Luxury Homes', 'Land & Lots', 'Rentals', 'Investment Properties', 'New Developments'],
  Destinations: ['Papagayo', 'Tamarindo', 'Nosara', 'Santa Teresa', 'Dominical', 'Manuel Antonio'],
  Company: ['About Us', 'Our Story', 'Team', 'Press', 'Contact'],
  Services: ['Buyer Representation', 'Investment Advisory', 'Legal Guidance', 'Property Management', 'Relocation Services'],
};

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) setSubscribed(true);
  };

  return (
    <footer className="bg-black border-t border-white/5">
      {/* Main footer */}
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16 py-20 lg:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">

          {/* Brand column */}
          <div className="lg:col-span-4">
            <div className="mb-8">
              <div
                className="text-white text-2xl font-light tracking-[0.12em] uppercase mb-1"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Tropical Realty
              </div>
              <div className="text-white/20 text-[10px] tracking-[0.4em] uppercase">
                Costa Rica · Luxury Real Estate · Est. 2008
              </div>
            </div>

            <p className="text-white/30 text-sm font-light leading-[1.9] max-w-xs mb-8">
              Costa Rica's most trusted luxury real estate agency. Serving international buyers with excellence since 2008.
            </p>

            {/* Newsletter */}
            <div className="mb-8">
              <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase mb-4">
                Market Intelligence Newsletter
              </div>
              {!subscribed ? (
                <form onSubmit={handleSubscribe} className="flex border-b border-white/20 pb-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your email address"
                    className="flex-1 bg-transparent text-white text-sm font-light placeholder-white/20 focus:outline-none"
                    required
                  />
                  <button type="submit" className="text-white/40 hover:text-white transition-colors pl-4">
                    <ArrowRight size={14} />
                  </button>
                </form>
              ) : (
                <div className="text-white/40 text-xs tracking-wider flex items-center gap-2">
                  <div className="w-4 h-px" style={{ backgroundColor: '#D4AF37' }} />
                  Subscribed. Thank you.
                </div>
              )}
            </div>

            {/* Social */}
            <div className="flex items-center gap-4">
              {[
                { label: 'IG', href: 'https://www.instagram.com/tropicalrealtycostarica' },
                { label: 'FB', href: '#' },
                { label: 'YT', href: '#' },
                { label: 'IN', href: '#' },
              ].map(({ label, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 flex items-center justify-center border border-white/10 text-white/30 hover:text-white hover:border-white/30 transition-all duration-300 text-[10px] tracking-wider font-light"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>

          {/* Links columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="lg:col-span-2">
              <div className="text-white/40 text-[9px] tracking-[0.4em] uppercase mb-6">
                {category}
              </div>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-white/30 text-xs font-light hover:text-white/70 transition-colors duration-300 tracking-wide"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/5">
        <div className="max-w-[1600px] mx-auto px-8 lg:px-16 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-white/20 text-[10px] tracking-wider">
              © 2024 Tropical Realty Costa Rica. All Rights Reserved.
            </div>
            <div className="flex items-center gap-6">
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="text-white/20 text-[10px] tracking-wider hover:text-white/40 transition-colors"
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

const heroImages = [
  'https://images.pexels.com/photos/17311460/pexels-photo-17311460.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920',
  'https://images.pexels.com/photos/31817160/pexels-photo-31817160.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920',
  'https://images.pexels.com/photos/15365635/pexels-photo-15365635.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920',
  'https://images.pexels.com/photos/35043038/pexels-photo-35043038.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920',
  'https://images.pexels.com/photos/4628191/pexels-photo-4628191.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920',
];

export default function HeroSection() {
  const [currentImage, setCurrentImage] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % heroImages.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToNext = () => {
    const el = document.querySelector('#properties');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section ref={heroRef} className="relative w-full h-screen overflow-hidden">
      {/* Background images with crossfade */}
      {heroImages.map((img, i) => (
        <motion.div
          key={img}
          initial={{ opacity: 0 }}
          animate={{ opacity: i === currentImage ? 1 : 0 }}
          transition={{ duration: 1.5, ease: 'easeInOut' }}
          className="absolute inset-0"
          style={{ transform: `translateY(${scrollY * 0.4}px)` }}
        >
          <img
            src={img}
            alt="Costa Rica luxury property"
            className="w-full h-full object-cover"
            style={{ transform: 'scale(1.05)' }}
          />
        </motion.div>
      ))}

      {/* Cinematic overlay */}
      <div
        className="absolute inset-0 z-10"
        style={{
          background: 'linear-gradient(to bottom, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.4) 75%, rgba(0,0,0,0.85) 100%)',
        }}
      />

      {/* Side gradient for depth */}
      <div
        className="absolute inset-0 z-10"
        style={{
          background: 'linear-gradient(to right, rgba(0,0,0,0.3) 0%, transparent 40%, transparent 60%, rgba(0,0,0,0.2) 100%)',
        }}
      />

      {/* Hero Content */}
      <div className="relative z-20 h-full flex flex-col justify-end pb-24 lg:pb-32 px-8 lg:px-16 max-w-[1600px] mx-auto w-full">

        {/* Gold accent line */}
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: 60 }}
          transition={{ duration: 1.5, delay: 0.5 }}
          className="h-px mb-8"
          style={{ backgroundColor: '#D4AF37' }}
        />

        {/* Main headline */}
        <div className="overflow-hidden">
          <motion.h1
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="text-white font-light leading-[0.9] mb-2"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(3rem, 8vw, 7rem)',
              letterSpacing: '-0.01em',
            }}
          >
            Luxury Properties.
          </motion.h1>
        </div>

        <div className="overflow-hidden">
          <motion.h1
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="text-white font-light leading-[0.9] mb-2"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(3rem, 8vw, 7rem)',
              letterSpacing: '-0.01em',
            }}
          >
            <em>Exceptional</em> Living.
          </motion.h1>
        </div>

        <div className="overflow-hidden">
          <motion.h1
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="font-light leading-[0.9] mb-10"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(3rem, 8vw, 7rem)',
              letterSpacing: '-0.01em',
              color: '#D4AF37',
            }}
          >
            Costa Rica.
          </motion.h1>
        </div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="text-white/60 text-sm font-light tracking-[0.2em] uppercase mb-10 max-w-md"
        >
          Premium Real Estate Since 2008 · Trusted by International Buyers
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.3 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <button
            onClick={() => document.querySelector('#properties')?.scrollIntoView({ behavior: 'smooth' })}
            className="luxury-btn group"
          >
            <span>Explore Properties</span>
            <span
              className="w-6 h-px transition-all duration-300 group-hover:w-10"
              style={{ backgroundColor: 'currentColor' }}
            />
          </button>
          <button
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="flex items-center gap-3 text-white/60 hover:text-white text-xs tracking-[0.25em] uppercase font-light transition-colors duration-300 py-4"
          >
            Book a Consultation
          </button>
        </motion.div>
      </div>

      {/* Image indicators */}
      <div className="absolute bottom-8 right-8 lg:right-16 z-20 flex gap-2">
        {heroImages.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentImage(i)}
            className="transition-all duration-500"
          >
            <div
              className="h-px transition-all duration-500"
              style={{
                width: i === currentImage ? 32 : 16,
                backgroundColor: i === currentImage ? '#D4AF37' : 'rgba(255,255,255,0.3)',
              }}
            />
          </button>
        ))}
      </div>

      {/* Scroll indicator */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        onClick={scrollToNext}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 text-white/40 hover:text-white/70 transition-colors duration-300"
      >
        <span className="text-[9px] tracking-[0.4em] uppercase">Scroll</span>
        <ArrowDown size={12} className="animate-scroll-bounce" />
      </motion.button>
    </section>
  );
}

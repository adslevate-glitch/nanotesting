import { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    quote: "Tropical Realty didn't just find us a house — they found us a new life. The level of professionalism and personal attention was unlike anything we experienced in our 20 years of real estate transactions.",
    author: 'Michael & Sarah Thompson',
    origin: 'New York, USA',
    property: 'Oceanfront Villa, Papagayo — $3.8M',
    image: 'https://images.pexels.com/photos/3764119/pexels-photo-3764119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=200',
  },
  {
    quote: "As an investor, I needed someone who understood both the market and the legal framework. Jorge and his team delivered exceptional due diligence and made the entire process seamless from London.",
    author: 'James Harrington',
    origin: 'London, UK',
    property: 'Investment Portfolio, Guanacaste — $2.1M',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=200',
  },
  {
    quote: "We were nervous about buying property in Central America. Tropical Realty made us feel completely secure every step of the way. Three years later, our home has appreciated 40% and we couldn't be happier.",
    author: 'Dr. Elena Müller',
    origin: 'Frankfurt, Germany',
    property: 'Jungle Estate, Manuel Antonio — $1.65M',
    image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=200',
  },
];

export default function TestimonialsSection() {
  const { ref, inView } = useInView({ threshold: 0.2, triggerOnce: true });
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  const t = testimonials[current];

  return (
    <section ref={ref} className="py-24 lg:py-40 overflow-hidden" style={{ backgroundColor: '#F5F0E8' }}>
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
            <span className="section-label">Client Stories</span>
          </div>
          <h2
            className="text-black font-light"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(2rem, 4vw, 3.5rem)',
            }}
          >
            Trusted by the World's
            <br />
            <em>Most Discerning Buyers</em>
          </h2>
        </motion.div>

        {/* Testimonial */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20 items-center">

          {/* Large quote */}
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                {/* Opening quote mark */}
                <div
                  className="text-8xl font-light leading-none mb-6"
                  style={{
                    fontFamily: 'Cormorant Garamond, serif',
                    color: '#D4AF37',
                    lineHeight: 0.7,
                  }}
                >
                  "
                </div>

                <blockquote
                  className="text-black font-light leading-[1.7] mb-10"
                  style={{
                    fontFamily: 'Cormorant Garamond, serif',
                    fontSize: 'clamp(1.2rem, 2.2vw, 1.8rem)',
                  }}
                >
                  {t.quote}
                </blockquote>

                <div className="flex items-center gap-6">
                  <img
                    src={t.image}
                    alt={t.author}
                    className="w-14 h-14 rounded-full object-cover grayscale"
                  />
                  <div>
                    <div className="text-black text-sm font-light tracking-wide">
                      {t.author}
                    </div>
                    <div className="text-black/40 text-xs tracking-wider mt-0.5">
                      {t.origin}
                    </div>
                    <div className="text-xs tracking-wider mt-1" style={{ color: '#D4AF37' }}>
                      {t.property}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center gap-6 mt-12">
              <button
                onClick={prev}
                className="w-12 h-12 flex items-center justify-center border border-black/15 text-black/40 hover:text-black hover:border-black transition-all duration-300"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={next}
                className="w-12 h-12 flex items-center justify-center border border-black/15 text-black/40 hover:text-black hover:border-black transition-all duration-300"
              >
                <ChevronRight size={16} />
              </button>
              <div className="flex gap-2 ml-4">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className="h-px transition-all duration-300"
                    style={{
                      width: i === current ? 32 : 16,
                      backgroundColor: i === current ? '#D4AF37' : 'rgba(0,0,0,0.2)',
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Right column - stats */}
          <div className="lg:col-span-4">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="border-l-2 pl-8 space-y-10"
              style={{ borderColor: '#D4AF37' }}
            >
              {[
                { n: '38+', l: 'Countries' },
                { n: '97%', l: 'Client Satisfaction' },
                { n: '12', l: 'Days Avg. to Close' },
                { n: '$0', l: 'Hidden Fees' },
              ].map((s) => (
                <div key={s.l}>
                  <div
                    className="text-4xl text-black font-light mb-1"
                    style={{ fontFamily: 'Cormorant Garamond, serif' }}
                  >
                    {s.n}
                  </div>
                  <div className="text-black/40 text-xs tracking-[0.25em] uppercase">
                    {s.l}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

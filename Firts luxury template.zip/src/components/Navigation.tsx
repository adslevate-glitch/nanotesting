import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Phone, ChevronDown } from 'lucide-react';

const navLinks = [
  { label: 'Properties', href: '#properties', hasDropdown: true, items: ['Luxury Homes', 'Land & Lots', 'Rentals', 'Investment'] },
  { label: 'Destinations', href: '#destinations' },
  { label: 'Lifestyle', href: '#lifestyle' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
          scrolled ? 'nav-solid' : 'nav-transparent'
        }`}
      >
        <div className="max-w-[1600px] mx-auto px-8 lg:px-16">
          <div className="flex items-center justify-between h-20 lg:h-24">

            {/* Logo */}
            <motion.a
              href="#"
              className="flex items-center gap-3 group"
              whileHover={{ opacity: 0.8 }}
            >
              <div className="flex flex-col">
                <span
                  className="text-white font-serif text-xl tracking-[0.15em] uppercase leading-tight"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  Tropical Realty
                </span>
                <span className="text-white/50 text-[10px] tracking-[0.4em] uppercase font-light">
                  Costa Rica · Est. 2008
                </span>
              </div>
            </motion.a>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-10">
              {navLinks.map((link) => (
                <div
                  key={link.label}
                  className="relative"
                  onMouseEnter={() => link.hasDropdown && setActiveDropdown(link.label)}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="flex items-center gap-1 text-white/80 hover:text-white text-[11px] tracking-[0.25em] uppercase font-light animated-underline transition-colors duration-300"
                  >
                    {link.label}
                    {link.hasDropdown && <ChevronDown size={10} />}
                  </button>

                  {link.hasDropdown && (
                    <AnimatePresence>
                      {activeDropdown === link.label && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          transition={{ duration: 0.2 }}
                          className="absolute top-8 left-0 bg-black/95 backdrop-blur-xl border border-white/10 min-w-[180px] py-2"
                        >
                          {link.items?.map((item) => (
                            <button
                              key={item}
                              className="block w-full text-left px-6 py-3 text-white/60 hover:text-white hover:bg-white/5 text-[10px] tracking-[0.25em] uppercase transition-all duration-200"
                            >
                              {item}
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  )}
                </div>
              ))}
            </div>

            {/* Right side */}
            <div className="hidden lg:flex items-center gap-6">
              <a
                href="tel:+50683888809"
                className="flex items-center gap-2 text-white/60 hover:text-white transition-colors duration-300"
              >
                <Phone size={12} />
                <span className="text-[10px] tracking-[0.2em] font-light">+506 8388 8809</span>
              </a>
              <button
                onClick={() => handleNavClick('#contact')}
                className="px-6 py-2.5 border border-white/30 text-white text-[10px] tracking-[0.25em] uppercase hover:bg-white hover:text-black transition-all duration-400 font-light"
              >
                Book Consultation
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden text-white p-2"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="fixed inset-0 z-40 bg-black flex flex-col justify-center px-10"
          >
            <div className="flex flex-col gap-8">
              {navLinks.map((link, i) => (
                <motion.button
                  key={link.label}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08, duration: 0.5 }}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left text-white text-4xl font-light tracking-wide animated-underline"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  {link.label}
                </motion.button>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute bottom-16 left-10 right-10"
            >
              <div className="border-t border-white/10 pt-8">
                <a href="tel:+50683888809" className="flex items-center gap-3 text-white/60 mb-4">
                  <Phone size={14} />
                  <span className="text-sm tracking-widest">+506 8388 8809</span>
                </a>
                <a href="mailto:Jorge@tropicalrealtycostarica.com" className="text-white/40 text-xs tracking-widest">
                  Jorge@tropicalrealtycostarica.com
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

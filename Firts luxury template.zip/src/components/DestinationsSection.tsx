import { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

const destinations = [
  {
    name: 'Papagayo',
    region: 'Guanacaste',
    description: 'Ultra-luxury peninsula. World-class marinas, Four Seasons resort, and the most exclusive estates in Costa Rica.',
    properties: '24 Properties',
    image: 'https://images.pexels.com/photos/15365635/pexels-photo-15365635.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['Ocean Views', 'Ultra-Luxury', 'Marina'],
  },
  {
    name: 'Tamarindo',
    region: 'Guanacaste',
    description: 'The original surf town transformed into a cosmopolitan luxury destination. International restaurants, art galleries, vibrant nightlife.',
    properties: '38 Properties',
    image: 'https://images.pexels.com/photos/100362/pexels-photo-100362.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['Surf', 'Lifestyle', 'Investment'],
  },
  {
    name: 'Nosara',
    region: 'Guanacaste',
    description: 'Yoga capital of the Americas. Pristine nature reserves, world-renowned surf breaks, and a mindful luxury community.',
    properties: '19 Properties',
    image: 'https://images.pexels.com/photos/17582137/pexels-photo-17582137.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['Wellness', 'Nature', 'Privacy'],
  },
  {
    name: 'Santa Teresa',
    region: 'Puntarenas',
    description: 'The hottest bohemian luxury destination. Clifftop villas, celebrity hideaways, and breathtaking Pacific sunsets.',
    properties: '31 Properties',
    image: 'https://images.pexels.com/photos/128449/pexels-photo-128449.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['Trendy', 'Surf', 'Villas'],
  },
  {
    name: 'Dominical',
    region: 'Puntarenas',
    description: 'Where the rainforest meets the Pacific. Dramatic landscapes, rare biodiversity, and untouched natural luxury.',
    properties: '14 Properties',
    image: 'https://images.pexels.com/photos/6416326/pexels-photo-6416326.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['Adventure', 'Nature', 'Rainforest'],
  },
  {
    name: 'Manuel Antonio',
    region: 'Puntarenas',
    description: 'National Park paradise. Luxury estates perched above one of the world\'s most beautiful national parks.',
    properties: '27 Properties',
    image: 'https://images.pexels.com/photos/38145936/pexels-photo-38145936.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600',
    tags: ['National Park', 'Wildlife', 'Views'],
  },
];

export default function DestinationsSection() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <section id="destinations" ref={ref} className="bg-black py-24 lg:py-40">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Featured Destinations</span>
            </div>
            <h2
              className="text-white font-light leading-[1.05]"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              }}
            >
              Where Would You
              <br />
              <em style={{ color: '#D4AF37' }}>Like to Live?</em>
            </h2>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-white/30 text-sm font-light max-w-xs lg:text-right mt-6 lg:mt-0"
          >
            Each destination offers a unique lifestyle. We help you find the one that feels like home.
          </motion.p>
        </div>

        {/* Destinations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
          {destinations.map((dest, i) => (
            <motion.div
              key={dest.name}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.7 }}
              className="relative overflow-hidden cursor-pointer group"
              style={{ height: '420px' }}
              onMouseEnter={() => setHovered(dest.name)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Background Image */}
              <img
                src={dest.image}
                alt={dest.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700"
                style={{ transform: hovered === dest.name ? 'scale(1.08)' : 'scale(1)' }}
              />

              {/* Dark overlay - darkens more on hover */}
              <div
                className="absolute inset-0 transition-opacity duration-500"
                style={{
                  background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0.2) 100%)',
                  opacity: hovered === dest.name ? 1 : 0.8,
                }}
              />

              {/* Content */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                {/* Tags */}
                <motion.div
                  className="flex gap-2 mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: hovered === dest.name ? 1 : 0, y: hovered === dest.name ? 0 : 20 }}
                  transition={{ duration: 0.3 }}
                >
                  {dest.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 text-[9px] tracking-[0.2em] uppercase text-white/70 border border-white/20"
                    >
                      {tag}
                    </span>
                  ))}
                </motion.div>

                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase mb-2">
                      {dest.region}
                    </div>
                    <h3
                      className="text-white font-light text-3xl lg:text-4xl"
                      style={{ fontFamily: 'Playfair Display, serif' }}
                    >
                      {dest.name}
                    </h3>
                    <p
                      className="text-white/50 text-xs font-light mt-1 max-w-xs leading-relaxed transition-all duration-400"
                      style={{
                        maxHeight: hovered === dest.name ? '100px' : '0',
                        overflow: 'hidden',
                        opacity: hovered === dest.name ? 1 : 0,
                        marginTop: hovered === dest.name ? '8px' : '0',
                      }}
                    >
                      {dest.description}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <div
                      className="w-10 h-10 flex items-center justify-center border text-white transition-all duration-300"
                      style={{
                        borderColor: hovered === dest.name ? '#D4AF37' : 'rgba(255,255,255,0.2)',
                        backgroundColor: hovered === dest.name ? '#D4AF37' : 'transparent',
                        color: hovered === dest.name ? '#000' : '#fff',
                      }}
                    >
                      <ArrowUpRight size={14} />
                    </div>
                    <div className="text-white/30 text-[9px] tracking-[0.2em] uppercase">
                      {dest.properties}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, ArrowRight, MessageCircle } from 'lucide-react';

export default function ContactSection() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    interest: '',
    budget: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" ref={ref} className="min-h-screen bg-black overflow-hidden">
      <div className="grid lg:grid-cols-2 min-h-screen">

        {/* Left - Image & Contact Info */}
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 1 }}
          className="relative hidden lg:flex flex-col justify-end p-16"
        >
          <img
            src="https://images.pexels.com/photos/12715491/pexels-photo-12715491.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900"
            alt="Luxury Costa Rica Property"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.2) 100%)',
            }}
          />

          {/* Contact info */}
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-10 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Get in Touch</span>
            </div>

            <h2
              className="text-white font-light leading-[1.05] mb-10"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(1.8rem, 2.5vw, 2.8rem)',
              }}
            >
              Your Journey to
              <br />
              <em style={{ color: '#D4AF37' }}>Costa Rica Begins Here</em>
            </h2>

            <div className="space-y-6">
              <a href="tel:+50683888809" className="flex items-center gap-4 text-white/60 hover:text-white transition-colors group">
                <div className="w-10 h-10 flex items-center justify-center border border-white/20 group-hover:border-white/50 transition-colors">
                  <Phone size={14} />
                </div>
                <div>
                  <div className="text-[9px] tracking-[0.3em] uppercase text-white/30 mb-0.5">Phone / WhatsApp</div>
                  <div className="text-sm font-light">+506 8388 8809</div>
                </div>
              </a>

              <a href="mailto:Jorge@tropicalrealtycostarica.com" className="flex items-center gap-4 text-white/60 hover:text-white transition-colors group">
                <div className="w-10 h-10 flex items-center justify-center border border-white/20 group-hover:border-white/50 transition-colors">
                  <Mail size={14} />
                </div>
                <div>
                  <div className="text-[9px] tracking-[0.3em] uppercase text-white/30 mb-0.5">Email</div>
                  <div className="text-sm font-light">Jorge@tropicalrealtycostarica.com</div>
                </div>
              </a>

              <div className="flex items-center gap-4 text-white/60">
                <div className="w-10 h-10 flex items-center justify-center border border-white/20">
                  <MapPin size={14} />
                </div>
                <div>
                  <div className="text-[9px] tracking-[0.3em] uppercase text-white/30 mb-0.5">Location</div>
                  <div className="text-sm font-light">Costa Rica · Nationwide Service</div>
                </div>
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/50683888809"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 mt-8 text-white text-xs tracking-[0.2em] uppercase border-b pb-4 border-white/10 hover:border-white/30 transition-colors group"
            >
              <MessageCircle size={14} style={{ color: '#25D366' }} />
              <span>Chat on WhatsApp</span>
              <ArrowRight size={12} className="ml-auto transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </div>
        </motion.div>

        {/* Right - Form */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 1, delay: 0.2 }}
          className="flex flex-col justify-center p-8 lg:p-16 xl:p-24"
        >
          <div className="max-w-md w-full mx-auto lg:mx-0">

            {/* Mobile header */}
            <div className="lg:hidden mb-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-10 h-px" style={{ backgroundColor: '#D4AF37' }} />
                <span className="section-label">Get in Touch</span>
              </div>
              <h2
                className="text-white font-light"
                style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem' }}
              >
                Begin Your Journey
              </h2>
            </div>

            {!submitted ? (
              <>
                <p className="text-white/30 text-xs tracking-[0.2em] uppercase mb-12 hidden lg:block">
                  Book a Private Consultation
                </p>

                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">First Name</label>
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        className="luxury-input"
                        placeholder="John"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Last Name</label>
                      <input
                        type="text"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        className="luxury-input"
                        placeholder="Smith"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="luxury-input"
                      placeholder="john@example.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Phone / WhatsApp</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="luxury-input"
                      placeholder="+1 (000) 000-0000"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Interest</label>
                    <select
                      value={formData.interest}
                      onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                      className="luxury-input bg-transparent cursor-pointer"
                    >
                      <option value="" className="bg-black">Select an interest</option>
                      <option value="luxury" className="bg-black">Luxury Home</option>
                      <option value="investment" className="bg-black">Investment Property</option>
                      <option value="land" className="bg-black">Land & Lots</option>
                      <option value="rental" className="bg-black">Rental Property</option>
                      <option value="consultation" className="bg-black">General Consultation</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Budget Range</label>
                    <select
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className="luxury-input bg-transparent cursor-pointer"
                    >
                      <option value="" className="bg-black">Select budget</option>
                      <option value="500k" className="bg-black">$500K - $1M</option>
                      <option value="1m" className="bg-black">$1M - $2M</option>
                      <option value="2m" className="bg-black">$2M - $5M</option>
                      <option value="5m" className="bg-black">$5M+</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-[0.3em] uppercase text-white/30 mb-3">Message</label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="luxury-input resize-none"
                      placeholder="Tell us about your vision..."
                      rows={3}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-3 py-4 text-black text-xs tracking-[0.3em] uppercase font-light transition-all duration-300 hover:opacity-80"
                    style={{ backgroundColor: '#D4AF37' }}
                  >
                    Send Enquiry
                    <ArrowRight size={12} />
                  </button>

                  <p className="text-white/20 text-[10px] text-center tracking-wider">
                    We respond within 24 hours. All conversations are strictly confidential.
                  </p>
                </form>
              </>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-16"
              >
                <div className="w-16 h-px mx-auto mb-8" style={{ backgroundColor: '#D4AF37' }} />
                <h3
                  className="text-white text-2xl font-light mb-4"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  Thank You
                </h3>
                <p className="text-white/40 text-sm font-light leading-relaxed max-w-xs mx-auto">
                  Your enquiry has been received. Jorge will personally reach out within 24 hours.
                </p>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

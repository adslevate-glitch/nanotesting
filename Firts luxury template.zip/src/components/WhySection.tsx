import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';

const features = [
  {
    number: '01',
    title: '15+ Years of\nLocal Expertise',
    description: 'Since 2008, we have been Costa Rica\'s most trusted real estate partner for international buyers. Our deep roots and local knowledge are unmatched.',
    image: 'https://images.pexels.com/photos/15365635/pexels-photo-15365635.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900',
  },
  {
    number: '02',
    title: 'Global Standards,\nLocal Mastery',
    description: 'We understand international buyers. With clients from 38+ countries, we speak your language—in every sense. Seamless, transparent, professional.',
    image: 'https://images.pexels.com/photos/31817157/pexels-photo-31817157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900',
  },
  {
    number: '03',
    title: 'Investment\nIntelligence',
    description: 'We don\'t just sell properties—we guide investments. Our market analysis, ROI projections, and legal expertise protect and grow your capital.',
    image: 'https://images.pexels.com/photos/12186850/pexels-photo-12186850.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900',
  },
];

export default function WhySection() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section ref={ref} className="py-24 lg:py-40 overflow-hidden" style={{ backgroundColor: '#F5F0E8' }}>
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20 lg:mb-32"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
            <span className="section-label">Why Choose Us</span>
          </div>
          <h2
            className="text-black font-light leading-[1.05] max-w-2xl"
            style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(2rem, 4vw, 3.5rem)',
            }}
          >
            The Definitive Partner
            <br />
            <em>For Your Costa Rica Investment</em>
          </h2>
        </motion.div>

        {/* Features - alternating layout */}
        <div className="space-y-24 lg:space-y-40">
          {features.map((feature, i) => (
            <FeatureRow key={feature.number} feature={feature} index={i} inView={inView} />
          ))}
        </div>

        {/* Bottom trust indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mt-24 lg:mt-40 pt-16 border-t border-black/10 grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {[
            { label: 'Licensed & Certified', sub: 'Costa Rica Real Estate Board' },
            { label: 'International Network', sub: 'Global Partner Agencies' },
            { label: 'Full Legal Support', sub: 'Integrated Legal Team' },
            { label: 'Post-Sale Service', sub: 'Property Management' },
          ].map((item) => (
            <div key={item.label}>
              <div className="w-8 h-px mb-4" style={{ backgroundColor: '#D4AF37' }} />
              <div className="text-black text-sm font-light mb-1">{item.label}</div>
              <div className="text-black/40 text-xs tracking-wider">{item.sub}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function FeatureRow({ feature, index, inView }: { feature: typeof features[0], index: number, inView: boolean }) {
  const isEven = index % 2 === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ delay: index * 0.2, duration: 0.9 }}
      className={`grid lg:grid-cols-2 gap-12 lg:gap-20 items-center ${isEven ? '' : ''}`}
    >
      {/* Image */}
      <div className={`relative overflow-hidden ${isEven ? 'lg:order-1' : 'lg:order-2'}`}>
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={feature.image}
            alt={feature.title}
            className="w-full h-full object-cover property-card-img group-hover:scale-105"
            style={{ transition: 'transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)' }}
          />
        </div>
        {/* Number overlay */}
        <div
          className="absolute -bottom-4 -right-4 lg:-bottom-8 lg:-right-8 text-[6rem] lg:text-[9rem] font-light text-black/5 leading-none select-none"
          style={{ fontFamily: 'Cormorant Garamond, serif' }}
        >
          {feature.number}
        </div>
      </div>

      {/* Content */}
      <div className={`${isEven ? 'lg:order-2' : 'lg:order-1'}`}>
        <div
          className="text-black/15 text-lg font-light mb-4 tracking-widest"
          style={{ fontFamily: 'Cormorant Garamond, serif' }}
        >
          {feature.number}
        </div>
        <h3
          className="text-black font-light leading-[1.1] mb-6"
          style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(1.6rem, 2.5vw, 2.5rem)',
            whiteSpace: 'pre-line',
          }}
        >
          {feature.title}
        </h3>
        <div className="w-10 h-px mb-6" style={{ backgroundColor: '#D4AF37' }} />
        <p className="text-black/50 text-sm font-light leading-[1.9] max-w-md">
          {feature.description}
        </p>
      </div>
    </motion.div>
  );
}

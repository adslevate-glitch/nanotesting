import { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { Search, MapPin, Home, DollarSign, BedDouble, Eye, TrendingUp, ArrowRight } from 'lucide-react';

const properties = [
  {
    id: 1,
    title: 'Ocean View Estate',
    location: 'Papagayo Peninsula',
    price: '$4,850,000',
    beds: 6,
    baths: 7,
    sqft: '8,400',
    tag: 'Luxury Residence',
    image: 'https://images.pexels.com/photos/31817160/pexels-photo-31817160.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: true,
    type: 'home',
  },
  {
    id: 2,
    title: 'Jungle Villa',
    location: 'Manuel Antonio',
    price: '$2,200,000',
    beds: 4,
    baths: 4,
    sqft: '4,800',
    tag: 'Private Estate',
    image: 'https://images.pexels.com/photos/17311460/pexels-photo-17311460.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: false,
    type: 'home',
  },
  {
    id: 3,
    title: 'Beachfront Penthouse',
    location: 'Tamarindo',
    price: '$1,750,000',
    beds: 3,
    baths: 3,
    sqft: '3,200',
    tag: 'Ocean Front',
    image: 'https://images.pexels.com/photos/12715491/pexels-photo-12715491.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: false,
    type: 'home',
  },
  {
    id: 4,
    title: 'Cliffside Villa',
    location: 'Nosara',
    price: '$3,400,000',
    beds: 5,
    baths: 5,
    sqft: '6,500',
    tag: 'Panoramic Views',
    image: 'https://images.pexels.com/photos/35043038/pexels-photo-35043038.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: true,
    type: 'home',
  },
  {
    id: 5,
    title: 'Rainforest Land',
    location: 'Uvita',
    price: '$890,000',
    beds: 0,
    baths: 0,
    sqft: '45 acres',
    tag: 'Investment Land',
    image: 'https://images.pexels.com/photos/12186850/pexels-photo-12186850.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: false,
    type: 'land',
  },
  {
    id: 6,
    title: 'Luxury Pool Villa',
    location: 'Santa Teresa',
    price: '$2,800,000',
    beds: 5,
    baths: 5,
    sqft: '5,800',
    tag: 'Surf & Luxury',
    image: 'https://images.pexels.com/photos/34790496/pexels-photo-34790496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    featured: false,
    type: 'home',
  },
];

const locations = ['All Locations', 'Papagayo', 'Tamarindo', 'Nosara', 'Santa Teresa', 'Dominical', 'Uvita', 'Manuel Antonio'];
const types = ['All Types', 'Luxury Homes', 'Land & Lots', 'Rentals', 'Investment'];
const priceRanges = ['Any Price', 'Under $1M', '$1M - $2M', '$2M - $5M', '$5M+'];

export default function PropertySearch() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [selectedType, setSelectedType] = useState('All Types');
  const [selectedPrice, setSelectedPrice] = useState('Any Price');
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  return (
    <section id="properties" ref={ref} className="bg-white py-24 lg:py-40">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <div className="grid lg:grid-cols-2 gap-12 mb-20 items-end">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Our Portfolio</span>
            </div>
            <h2
              className="text-black font-light leading-[1.1]"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              }}
            >
              Curated Properties
              <br />
              <em>For Exceptional Lives</em>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:text-right"
          >
            <p className="text-black/50 text-sm font-light leading-relaxed max-w-sm lg:ml-auto mb-8">
              Each property in our portfolio is personally vetted for quality, investment potential, and lifestyle excellence.
            </p>
          </motion.div>
        </div>

        {/* Search Panel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mb-16"
        >
          <div className="border border-black/10 p-6 lg:p-8 bg-white shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 items-end">

              {/* Location */}
              <div className="lg:col-span-1">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin size={12} className="text-black/30" />
                  <label className="text-[10px] tracking-[0.3em] uppercase text-black/40 font-light">Location</label>
                </div>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full bg-transparent border-b border-black/15 pb-2 text-black text-sm font-light focus:outline-none focus:border-black/40 transition-colors cursor-pointer appearance-none"
                >
                  {locations.map(l => <option key={l}>{l}</option>)}
                </select>
              </div>

              {/* Type */}
              <div className="lg:col-span-1">
                <div className="flex items-center gap-2 mb-3">
                  <Home size={12} className="text-black/30" />
                  <label className="text-[10px] tracking-[0.3em] uppercase text-black/40 font-light">Property Type</label>
                </div>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full bg-transparent border-b border-black/15 pb-2 text-black text-sm font-light focus:outline-none focus:border-black/40 transition-colors cursor-pointer appearance-none"
                >
                  {types.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>

              {/* Price */}
              <div className="lg:col-span-1">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign size={12} className="text-black/30" />
                  <label className="text-[10px] tracking-[0.3em] uppercase text-black/40 font-light">Price Range</label>
                </div>
                <select
                  value={selectedPrice}
                  onChange={(e) => setSelectedPrice(e.target.value)}
                  className="w-full bg-transparent border-b border-black/15 pb-2 text-black text-sm font-light focus:outline-none focus:border-black/40 transition-colors cursor-pointer appearance-none"
                >
                  {priceRanges.map(p => <option key={p}>{p}</option>)}
                </select>
              </div>

              {/* Features */}
              <div className="lg:col-span-1">
                <div className="flex items-center gap-2 mb-3">
                  <Eye size={12} className="text-black/30" />
                  <label className="text-[10px] tracking-[0.3em] uppercase text-black/40 font-light">Features</label>
                </div>
                <select
                  className="w-full bg-transparent border-b border-black/15 pb-2 text-black text-sm font-light focus:outline-none focus:border-black/40 transition-colors cursor-pointer appearance-none"
                >
                  <option>Any Features</option>
                  <option>Ocean View</option>
                  <option>Infinity Pool</option>
                  <option>Beachfront</option>
                  <option>Investment</option>
                </select>
              </div>

              {/* Search Button */}
              <div className="lg:col-span-1">
                <button className="w-full flex items-center justify-center gap-3 bg-black text-white py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-black/80 transition-colors duration-300">
                  <Search size={12} />
                  Search
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Properties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-black/5">
          {properties.map((property, i) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.7 }}
              className="property-card bg-white group cursor-pointer"
              onMouseEnter={() => setHoveredCard(property.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              {/* Image */}
              <div className="relative overflow-hidden h-72 lg:h-80">
                <img
                  src={property.image}
                  alt={property.title}
                  className="property-card-img w-full h-full object-cover"
                />

                {/* Overlay */}
                <div
                  className="absolute inset-0 transition-opacity duration-500"
                  style={{
                    background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.1) 60%, transparent 100%)',
                  }}
                />

                {/* Tags */}
                <div className="absolute top-5 left-5 flex gap-2">
                  {property.featured && (
                    <span
                      className="px-3 py-1 text-[9px] tracking-[0.3em] uppercase font-light text-black"
                      style={{ backgroundColor: '#D4AF37' }}
                    >
                      Featured
                    </span>
                  )}
                  <span className="px-3 py-1 text-[9px] tracking-[0.3em] uppercase font-light text-white bg-black/40 backdrop-blur-sm">
                    {property.tag}
                  </span>
                </div>

                {/* Price on image */}
                <div className="absolute bottom-5 left-5">
                  <div
                    className="text-white font-light"
                    style={{
                      fontFamily: 'Cormorant Garamond, serif',
                      fontSize: '1.6rem',
                    }}
                  >
                    {property.price}
                  </div>
                </div>

                {/* Arrow on hover */}
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: hoveredCard === property.id ? 1 : 0, x: hoveredCard === property.id ? 0 : -10 }}
                  className="absolute bottom-5 right-5"
                >
                  <div className="w-10 h-10 flex items-center justify-center border border-white/40 text-white backdrop-blur-sm">
                    <ArrowRight size={14} />
                  </div>
                </motion.div>
              </div>

              {/* Content */}
              <div className="p-6 bg-white">
                <div className="flex items-center gap-2 mb-2">
                  <MapPin size={10} className="text-black/30" />
                  <span className="text-[10px] tracking-[0.25em] uppercase text-black/40 font-light">
                    {property.location}
                  </span>
                </div>

                <h3
                  className="text-black text-lg font-light mb-4 group-hover:text-black/70 transition-colors"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  {property.title}
                </h3>

                {/* Specs */}
                <div className="flex items-center gap-5 text-[11px] text-black/40 tracking-wider border-t border-black/5 pt-4">
                  {property.beds > 0 && (
                    <span className="flex items-center gap-1.5">
                      <BedDouble size={11} />
                      {property.beds} Beds
                    </span>
                  )}
                  <span>{property.sqft} {property.beds > 0 ? 'sq.ft' : ''}</span>
                  <span className="flex items-center gap-1.5 ml-auto">
                    <TrendingUp size={10} style={{ color: '#D4AF37' }} />
                    <span style={{ color: '#D4AF37' }}>High ROI</span>
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="text-center mt-16"
        >
          <button className="luxury-btn-dark group">
            <span>View All Properties</span>
            <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-2" />
          </button>
        </motion.div>

      </div>
    </section>
  );
}

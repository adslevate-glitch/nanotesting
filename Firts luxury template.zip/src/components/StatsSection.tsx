import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';

const stats = [
  { number: '15+', label: 'Years of Excellence', sub: 'Established 2008' },
  { number: '500+', label: 'Properties Sold', sub: 'Luxury & Investment' },
  { number: '38', label: 'Nations Served', sub: 'International Clientele' },
  { number: '$2.4B', label: 'In Transactions', sub: 'Combined Portfolio' },
];

export default function StatsSection() {
  const { ref, inView } = useInView({ threshold: 0.2, triggerOnce: true });

  return (
    <section ref={ref} className="bg-black py-24 lg:py-32 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <div className="flex items-center gap-6 mb-20">
          <motion.div
            initial={{ width: 0 }}
            animate={inView ? { width: 60 } : {}}
            transition={{ duration: 1 }}
            className="h-px"
            style={{ backgroundColor: '#D4AF37' }}
          />
          <motion.span
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.3 }}
            className="section-label"
          >
            Our Track Record
          </motion.span>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-0 lg:divide-x lg:divide-white/10">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.15, duration: 0.7 }}
              className="px-0 lg:px-12 first:pl-0"
            >
              <div
                className="stat-number text-white mb-2"
                style={{
                  fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
                  fontFamily: 'Cormorant Garamond, serif',
                  fontWeight: 300,
                }}
              >
                {stat.number}
              </div>
              <div className="text-white text-sm font-light tracking-widest uppercase mb-1">
                {stat.label}
              </div>
              <div className="text-white/30 text-xs tracking-wider">
                {stat.sub}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

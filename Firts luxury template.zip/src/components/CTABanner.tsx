import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function CTABanner() {
  const { ref, inView } = useInView({ threshold: 0.2, triggerOnce: true });

  return (
    <section ref={ref} className="relative overflow-hidden py-24 lg:py-36" style={{ backgroundColor: '#F5F0E8' }}>
      {/* Background decorative element */}
      <div
        className="absolute right-0 top-0 w-1/3 h-full opacity-5 pointer-events-none select-none"
        style={{
          fontFamily: 'Cormorant Garamond, serif',
          fontSize: '20rem',
          color: '#000',
          lineHeight: 1,
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          paddingRight: '4rem',
        }}
      >
        CR
      </div>

      <div className="max-w-[1600px] mx-auto px-8 lg:px-16 relative z-10">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Take the First Step</span>
            </div>

            <h2
              className="text-black font-light leading-[1.05] mb-6"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              }}
            >
              Ready to Find Your
              <br />
              <em>Dream Property in Costa Rica?</em>
            </h2>

            <p className="text-black/40 text-sm font-light leading-[1.9] mb-10 max-w-md">
              Whether you're a first-time international buyer or an experienced real estate investor, we provide the guidance, expertise, and personal service you deserve.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="luxury-btn-dark group"
              >
                <span>Schedule a Consultation</span>
                <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-2" />
              </button>
              <a
                href="https://wa.me/50683888809"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-black/40 hover:text-black text-xs tracking-[0.25em] uppercase font-light transition-colors py-4"
              >
                Or Chat on WhatsApp
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

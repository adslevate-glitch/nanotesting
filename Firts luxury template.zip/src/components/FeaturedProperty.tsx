import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { MapPin, BedDouble, Bath, Square, ArrowRight, TrendingUp } from 'lucide-react';

export default function FeaturedProperty() {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section ref={ref} className="bg-white py-24 lg:py-40 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-8 lg:px-16">

        {/* Header */}
        <div className="flex items-center justify-between mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-px" style={{ backgroundColor: '#D4AF37' }} />
              <span className="section-label">Property of the Season</span>
            </div>
            <h2
              className="text-black font-light leading-[1.05]"
              style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(1.8rem, 3.5vw, 3rem)',
              }}
            >
              An Estate Beyond Compare
            </h2>
          </motion.div>
        </div>

        {/* Featured Property */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="grid lg:grid-cols-2 gap-px bg-black/5"
        >
          {/* Main Image */}
          <div className="relative overflow-hidden group" style={{ height: 'clamp(350px, 55vw, 650px)' }}>
            <img
              src="https://images.pexels.com/photos/31817160/pexels-photo-31817160.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200"
              alt="Papagayo Ocean Estate"
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)',
              }}
            />
            {/* Featured badge */}
            <div className="absolute top-6 left-6">
              <span
                className="px-4 py-2 text-[10px] tracking-[0.3em] uppercase font-light text-black"
                style={{ backgroundColor: '#D4AF37' }}
              >
                Exclusive Listing
              </span>
            </div>
            {/* Price */}
            <div className="absolute bottom-6 left-6">
              <div
                className="text-white font-light mb-1"
                style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '2.5rem' }}
              >
                $4,850,000
              </div>
              <div className="text-white/50 text-[10px] tracking-[0.3em] uppercase">
                Investment Grade · High ROI
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="bg-white p-10 lg:p-14 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={11} className="text-black/30" />
                <span className="text-[10px] tracking-[0.3em] uppercase text-black/40">
                  Papagayo Peninsula, Guanacaste
                </span>
              </div>
              <h3
                className="text-black font-light text-3xl lg:text-4xl mb-6 leading-[1.1]"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                Papagayo Ocean
                <br />
                <em>View Estate</em>
              </h3>

              <p className="text-black/40 text-sm font-light leading-[1.9] mb-8 max-w-sm">
                A once-in-a-generation oceanfront estate set on 2.4 acres of prime Papagayo Peninsula real estate. Six bedrooms, private infinity pool, direct beach access, and panoramic views of the Gulf of Papagayo.
              </p>

              {/* Specs */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { Icon: BedDouble, value: '6 Bedrooms' },
                  { Icon: Bath, value: '7 Bathrooms' },
                  { Icon: Square, value: '8,400 sq.ft' },
                  { Icon: TrendingUp, value: '14% ROI Est.' },
                ].map(({ Icon, value }) => (
                  <div key={value} className="flex items-center gap-3 py-3 border-b border-black/5">
                    <Icon size={13} className="text-black/30" />
                    <span className="text-black/60 text-xs font-light tracking-wide">{value}</span>
                  </div>
                ))}
              </div>

              {/* Investment highlights */}
              <div className="space-y-2 mb-8">
                <div className="text-[9px] tracking-[0.3em] uppercase text-black/30 mb-3">
                  Investment Highlights
                </div>
                {[
                  'Steps from Four Seasons Resort',
                  'Private beach access included',
                  'Established vacation rental income',
                  'Full property management available',
                ].map((highlight) => (
                  <div key={highlight} className="flex items-center gap-3">
                    <div className="w-1 h-1 rounded-full" style={{ backgroundColor: '#D4AF37' }} />
                    <span className="text-black/50 text-xs font-light">{highlight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="luxury-btn-dark group flex-1 justify-center"
              >
                <span>Request Private Tour</span>
                <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
              </button>
              <button className="px-6 py-4 text-[10px] tracking-[0.25em] uppercase font-light text-black/40 hover:text-black transition-colors border border-transparent hover:border-black/10">
                View Details
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
